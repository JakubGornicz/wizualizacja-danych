class Score ( ) : #klasa Score z 3 parametrami 
    def __init__(self, numbers, date, game) :
        self.numbers = numbers
        self.date = date
        self.game = game
