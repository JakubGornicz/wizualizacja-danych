from score import * #importujemy skrypt z pliku score.py

class ScoresArchive( ) : 
    def __init__(self, lista_obiektow): #inicjalizator
        self.lista_obiektow = lista_obiektow
        
    def find_in_scores(self, lista_liczb) : #metoda find_in_scores
        wyniki_archiwum = []
        for i in range(len(self.lista_obiektow)):
            ile = 0
            for j in lista_liczb:
                if(j in self.lista_obiektow[i].numbers):
                    ile += 1
            if ile == len(lista_liczb):
                wyniki_archiwum.append(self.lista_obiektow[i])
        return wyniki_archiwum        
                
                
    
