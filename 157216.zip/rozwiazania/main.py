from score import * #zaimportowanie skryptów score.py i scores_archive.py
from scores_archive import *

import random as r

archives_path = 'data/archives.txt' #ścieżka do pliku tekstowego z wynikami
def read_archive_file(path):
    lista_obiektow = [ ]
    with open(path, 'r') as file: 
        for line in file:
            line = line.replace('\n', '')
            line = line.split(',')
            if len(line) == 6 :
                game = 'mały lotek'
            else:
                game = 'duży lotek'
            date = str(line[-1])
            numbers = [int(x) for x in line[:(len(line)-1)]]
            lista_obiektow.append(Score(numbers, date, game))
    return lista_obiektow

losy = ScoresArchive(read_archive_file(archives_path))  #stworzenie obiektu klasy ScoresArchive

user_input = '#'    #pętla głowna programu
while user_input != '2' : #menu
    print("Menu. Wybierz jedną z dwóch dostępnych opcji: ")
    print("1. wylosuj liczby i sprawdź w archiwum\n2. koniec")
    user_input = input("wybierz polecenie: ") 
    if user_input == "1" : #opcja 1
        lista_liczb = [ ]
        if r.randint(0,1) == 1 : #mechanizm losowania liczb
            while len(lista_liczb) != 5 : #losowanie małego lotka
                liczba = r.randint(1,49)
                while liczba not in lista_liczb : #sprawdzamy czy liczba nie znajduje się już w liście
                     lista_liczb.append(liczba)   
                
        else: #opcja 2
            while len(lista_liczb) != 6 : #losowanie dużego lotka
                liczba = r.randint(1,49)
                while liczba not in lista_liczb : #sprawdzamy czy liczba nie znajduje się już w liście
                    lista_liczb.append(liczba)

        print("Wylosowano: ", lista_liczb) # zwracamy wylosowane liczby
        znalezione = losy.find_in_scores(lista_liczb) # szukamy wylosowanego wariantu w archiwum
        for i in znalezione:
            print("Data: {}, gra: {}".format(i.date, i.game)) # podajemy datę oraz jaka to gra (jeśli znajdziemy w archiwum)
        if len(znalezione) == 0 :
            print("Nie znaleziono") # komunikat jeśli wylosowany wariant nie znajduje się w archiwum
                
                
        
